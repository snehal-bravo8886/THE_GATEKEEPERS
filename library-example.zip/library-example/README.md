# Page & Pine — Community Library (CanTheySeeIt test app)

A local-only fictional library management website for testing the **Library Management** scenario in CanTheySeeIt. It uses fake accounts and fictional contact details. It deliberately contains access-control mistakes for an authorised classroom/demo security exercise.

## Run locally

Requires Node.js 20 or later. No external npm dependencies are required.

```bash
cd library-example
npm start
```

Open http://127.0.0.1:3200. Keep the terminal open while using the site. The server binds only to loopback (`127.0.0.1`). Do not deploy this intentionally vulnerable app to a public host or use real member data.

Run the automated demo checks in another terminal:

```bash
npm test
```

## Demo accounts

All accounts use password: `library123`.

| Username | Role | Purpose |
|---|---|---|
| `alice` | Customer A | Member A, owns a basket and two active loans |
| `bob` | Customer B | Member B, owns a separate basket and two active loans |
| `maya` | Librarian | Staff inventory, loan and directory UI |
| `manager` | Manager | Staff overview and directory UI |

## What the app does

- Browse, search and filter eight well-known fiction, biography, self-growth, history and technology books.
- Add books to a personal basket and check them out as 14-day loans.
- View personal active loans and due dates.
- Staff can review available/borrowed stock, member loans, overdue items, return a loan and update inventory.
- Seeded records show different members' borrowing history and active baskets so the demo works immediately.

## Included security test cases

The mistakes are intentionally in the API; the normal member interface does not advertise them. These are fake records in a local lab.

### Test 1 — Customer A can view Customer B's basket (BOLA / IDOR)

1. Sign in as `alice`.
2. Open browser DevTools (F12) → Console.
3. Run:

```js
fetch('/api/carts/bob').then(r => r.json()).then(console.log)
```

Expected secure behaviour: `403 Forbidden` (or `404`) because Alice does not own Bob's basket. Actual demo behaviour: returns Bob's basket, which includes his selected titles.

### Test 2 — Customer B can read the management directory (broken function-level access control)

1. Sign in as `bob`.
2. Open DevTools → Console.
3. Run:

```js
fetch('/api/management/directory').then(r => r.json()).then(console.log)
```

Expected secure behaviour: `403 Forbidden` because a customer is not library staff. Actual demo behaviour: returns all four fictional directory records, contact details and active-loan summaries.

### Test 3 — A customer can change library stock (missing role check)

1. Sign in as `alice` or `bob`.
2. Open DevTools → Console.
3. Run:

```js
fetch('/api/management/books/harry-potter/stock', {
  method: 'PATCH',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ available: 99 })
}).then(r => r.json()).then(console.log)
```

Expected secure behaviour: `403 Forbidden` because customers cannot edit inventory. Actual demo behaviour: stock is changed. Refresh the page to see updated availability.

### Reset the lab

Stop the server with Ctrl+C and restart `npm start`. The seeded in-memory data resets to its original state.

## CanTheySeeIt test-planning matrix

| Test | Role | Action | Expected | Deliberate actual result |
|---|---|---|---|---|
| LBR-01 | Customer A | GET `/api/carts/bob` | DENY | ALLOW |
| LBR-02 | Customer B | GET `/api/management/directory` | DENY | ALLOW |
| LBR-03 | Customer A | PATCH `/api/management/books/harry-potter/stock` | DENY | ALLOW |
| LBR-04 | Customer A | GET `/api/cart` | ALLOW | ALLOW |
| LBR-05 | Customer A | GET `/api/loans` | ALLOW | ALLOW |
| LBR-06 | Unauthenticated visitor | GET `/api/management/directory` | DENY | DENY |
| LBR-07 | Librarian | GET `/api/management/loans` | ALLOW | ALLOW |
| LBR-08 | Manager | POST `/api/management/loans/:id/return` | ALLOW | ALLOW |

## Safety and scope

This is a deliberately vulnerable teaching fixture. It binds to `127.0.0.1`, uses invented records and has no external dependencies or real authentication provider. Do not expose it to a public network. The three flaws are clearly documented here so the owner can reset and discuss them; they are not intended for production use.
