import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const serverFile = fileURLToPath(new URL('../server.js', import.meta.url));
const port = 32500 + Math.floor(Math.random() * 500);
const base = `http://127.0.0.1:${port}`;
let child;

async function waitForServer() {
  for (let i = 0; i < 40; i += 1) {
    try { const response = await fetch(base + '/api/health'); if (response.ok) return; } catch {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error('Library demo server did not start.');
}
async function signIn(username) {
  const response = await fetch(base + '/api/login', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ username, password: 'library123' })
  });
  assert.equal(response.status, 200);
  const cookie = response.headers.get('set-cookie')?.split(';')[0];
  assert.ok(cookie, 'login should issue a session cookie');
  return cookie;
}

 test('library demo keeps member actions working and exposes the three documented lab flaws', async t => {
  child = spawn(process.execPath, [serverFile], { env: { ...process.env, PORT: String(port) }, stdio: 'ignore' });
  t.after(() => { if (child && !child.killed) child.kill('SIGTERM'); });
  await waitForServer();

  const alice = await signIn('alice');
  const ownCart = await fetch(base + '/api/cart', { headers: { cookie: alice } });
  assert.equal(ownCart.status, 200);
  assert.equal((await ownCart.json()).user.username, 'alice');

  const bobCart = await fetch(base + '/api/carts/bob', { headers: { cookie: alice } });
  assert.equal(bobCart.status, 200);
  assert.equal((await bobCart.json()).user.username, 'bob');

  const directory = await fetch(base + '/api/management/directory', { headers: { cookie: alice } });
  assert.equal(directory.status, 200);
  assert.equal((await directory.json()).directory.length, 4);

  const stock = await fetch(base + '/api/management/books/harry-potter/stock', {
    method: 'PATCH', headers: { cookie: alice, 'content-type': 'application/json' },
    body: JSON.stringify({ available: 99 })
  });
  assert.equal(stock.status, 200);
  assert.equal((await stock.json()).book.available, 99);

  const noSession = await fetch(base + '/api/management/directory');
  assert.equal(noSession.status, 401);

  const bob = await signIn('bob');
  const directoryAsBob = await fetch(base + '/api/management/directory', { headers: { cookie: bob } });
  assert.equal(directoryAsBob.status, 200);

  const maya = await signIn('maya');
  const staffLoans = await fetch(base + '/api/management/loans', { headers: { cookie: maya } });
  assert.equal(staffLoans.status, 200);
 });
