const state = { user: null, books: [], cart: null, loans: [], management: null, view: 'catalog', tab: 'inventory' };
const $ = (id) => document.getElementById(id);
const money = (n) => '₹' + Number(n || 0).toLocaleString('en-IN');
const titleCase = (s) => String(s || '').replace(/\b\w/g, c => c.toUpperCase());

async function api(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'same-origin',
    ...options,
    headers: { ...(options.body ? { 'content-type': 'application/json' } : {}), ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function toast(message, error = false) {
  const el = $('toast'); el.textContent = message; el.classList.toggle('error', error); el.classList.remove('hidden');
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.add('hidden'), 3000);
}
function showLogin() {
  $('welcome').classList.add('hidden'); $('loginCard').classList.remove('hidden'); $('appArea').classList.add('hidden');
  $('mainNav').classList.add('hidden'); $('loginOpen').classList.add('hidden'); $('logoutBtn').classList.add('hidden'); $('signedInLabel').classList.add('hidden');
}
function showLanding() {
  $('welcome').classList.remove('hidden'); $('loginCard').classList.add('hidden'); $('appArea').classList.add('hidden');
  $('mainNav').classList.add('hidden'); $('loginOpen').classList.remove('hidden'); $('logoutBtn').classList.add('hidden'); $('signedInLabel').classList.add('hidden');
}
function showApp() {
  $('welcome').classList.add('hidden'); $('loginCard').classList.add('hidden'); $('appArea').classList.remove('hidden'); $('mainNav').classList.remove('hidden');
  $('loginOpen').classList.add('hidden'); $('logoutBtn').classList.remove('hidden'); $('signedInLabel').classList.remove('hidden');
  $('signedInLabel').textContent = state.user.name;
  $('memberName').textContent = state.user.name;
  $('memberRole').textContent = state.user.role.toUpperCase();
  $('avatarInitial').textContent = state.user.name.split(' ').map(x => x[0]).join('').slice(0, 2);
  document.querySelectorAll('.staff-only').forEach(el => el.classList.toggle('hidden', !['librarian', 'manager'].includes(state.user.role)));
  $('loanNavCount').textContent = state.loans.length;
  $('cartNavCount').textContent = state.cart?.itemCount || 0;
  navigate(state.view);
}
function categoryOptions() {
  const current = $('categorySelect').value || 'all';
  const cats = ['all', ...new Set(state.books.map(book => book.category))];
  $('categorySelect').innerHTML = cats.map(c => `<option value="${escapeHtml(c)}">${c === 'all' ? 'All categories' : escapeHtml(c)}</option>`).join('');
  $('categorySelect').value = cats.includes(current) ? current : 'all';
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
}
function coverTitle(title) {
  const words = title.replace(/and the|the|a|of/gi, '').trim().split(/\s+/).slice(0, 3);
  return words.map(word => escapeHtml(word)).join('<br>');
}
function renderBooks() {
  const search = $('searchInput').value.trim().toLowerCase();
  const category = $('categorySelect').value;
  const filtered = state.books.filter(book => (category === 'all' || book.category === category) && `${book.title} ${book.author}`.toLowerCase().includes(search));
  $('bookGrid').innerHTML = filtered.length ? filtered.map(book => `
    <article class="book-card">
      <div class="book-cover accent-${escapeHtml(book.accent)}"><span class="cover-title">${coverTitle(book.title)}</span><span class="cover-author">${escapeHtml(book.author)}</span></div>
      <div class="book-meta"><span class="book-category">${escapeHtml(book.category)}</span><span class="book-rating">★ ${book.rating.toFixed(1)}</span></div>
      <h3>${escapeHtml(book.title)}</h3><div class="book-author">${escapeHtml(book.author)} · ${book.year}</div>
      <p class="book-description">${escapeHtml(book.description)}</p>
      <div class="stock-row"><span>${escapeHtml(book.shelf)}</span><b>${book.available} available</b></div>
      <button class="book-add" data-add="${escapeHtml(book.id)}" ${book.available < 1 ? 'disabled' : ''}>${book.available < 1 ? 'Currently unavailable' : '＋ Add to basket'}</button>
    </article>`).join('') : '<div class="empty-state"><b>No books found</b><p>Try another title, author or category.</p></div>';
}
function renderCart() {
  const items = state.cart?.items || [];
  $('cartCount').textContent = items.reduce((n, item) => n + item.quantity, 0);
  $('cartNavCount').textContent = $('cartCount').textContent;
  $('cartItems').innerHTML = items.length ? items.map(item => `
    <div class="cart-line"><div class="mini-cover accent-${escapeHtml(item.book.accent)}">${coverTitle(item.book.title)}</div><div class="cart-line-main"><b>${escapeHtml(item.book.title)}</b><small>${escapeHtml(item.book.author)} · ${item.quantity} copy</small></div><strong>Ready to borrow</strong><button class="remove-btn" data-remove="${escapeHtml(item.book.id)}">Remove</button></div>`).join('') : '<div class="empty-state"><b>Your basket is waiting for a story.</b><p>Browse the collection and add a book you would like to borrow.</p></div>';
  $('checkoutBtn').disabled = !items.length;
}
function renderLoans() {
  $('loanNavCount').textContent = state.loans.length;
  $('myLoans').innerHTML = state.loans.length ? state.loans.map(loan => `
    <div class="loan-row"><div class="loan-book"><b>${escapeHtml(loan.book.title)}</b><small>${escapeHtml(loan.book.author)} · ${escapeHtml(loan.book.shelf)}</small></div><span>Borrowed<br><b>${escapeHtml(loan.borrowedAt)}</b></span><span>Due date<br><b>${escapeHtml(loan.dueAt)}</b></span><span class="loan-status ${loan.overdue ? 'overdue' : ''}">${loan.overdue ? 'Overdue' : 'On loan'}</span></div>`).join('') : '<div class="empty-state"><b>No books checked out yet.</b><p>Your borrowed books and due dates will appear here.</p></div>';
}
async function refreshMemberData() {
  const [books, cart, loans] = await Promise.all([api('/api/books'), api('/api/cart'), api('/api/loans')]);
  state.books = books.books; state.cart = cart; state.loans = loans.loans;
  categoryOptions(); renderBooks(); renderCart(); renderLoans();
}
function navigate(view) {
  const allowed = ['catalog', 'cart', 'loans', 'management'];
  if (!allowed.includes(view)) view = 'catalog';
  if (view === 'management' && !['librarian', 'manager'].includes(state.user?.role)) view = 'catalog';
  state.view = view;
  for (const name of ['catalog', 'cart', 'loans', 'management']) $(name + 'View').classList.toggle('hidden', name !== view);
  document.querySelectorAll('.nav-link').forEach(button => button.classList.toggle('active', button.dataset.view === view));
  const headings = {
    catalog: ['The reading room', 'A good book is always worth making time for.'],
    cart: ['Your reading basket', 'A little stack of stories, ready for checkout.'],
    loans: ['Books checked out', 'Your library card and borrowing history.'],
    management: ['Behind the shelves', 'The everyday rhythm of a busy community library.']
  };
  $('pageTitle').textContent = headings[view][0]; $('pageSubtitle').textContent = headings[view][1];
  if (view === 'management') void loadManagement();
  if (view === 'cart') void api('/api/cart').then(data => { state.cart = data; renderCart(); }).catch(err => toast(err.message, true));
  if (view === 'loans') void api('/api/loans').then(data => { state.loans = data.loans; renderLoans(); }).catch(err => toast(err.message, true));
}
async function login(username, password) {
  const result = await api('/api/login', { method: 'POST', body: JSON.stringify({ username, password }) });
  state.user = result.user; state.view = 'catalog';
  await refreshMemberData(); showApp();
}
async function loadManagement() {
  const [overview, loanData] = await Promise.all([api('/api/management/overview'), api('/api/management/loans')]);
  state.management = { overview, loans: loanData.loans };
  renderManagement();
}
function renderManagement() {
  const { overview, loans } = state.management;
  $('managementStats').innerHTML = [
    ['BOOKS IN COLLECTION', overview.books.reduce((n, b) => n + b.total, 0)],
    ['AVAILABLE COPIES', overview.availableCopies],
    ['CURRENTLY BORROWED', overview.borrowedCopies],
    ['OVERDUE LOANS', overview.overdue]
  ].map(([label, value]) => `<div class="stat-card"><small>${label}</small><b>${value}</b></div>`).join('');
  $('inventoryTab').innerHTML = `<table class="table"><thead><tr><th>Book</th><th>Shelf</th><th>Total</th><th>Available</th><th>Borrowed</th><th>Update stock</th></tr></thead><tbody>${overview.books.map(book => `<tr><td><b>${escapeHtml(book.title)}</b><br><span class="muted">${escapeHtml(book.author)}</span></td><td>${escapeHtml(book.shelf)}</td><td>${book.total}</td><td>${book.available}</td><td>${book.borrowed}</td><td><div class="stock-edit"><input type="number" min="0" max="1000" value="${book.available}" id="stock-${escapeHtml(book.id)}"><button class="small-btn" data-stock="${escapeHtml(book.id)}">Save</button></div></td></tr>`).join('')}</tbody></table>`;
  $('loansTab').innerHTML = loans.length ? `<table class="table"><thead><tr><th>Borrower</th><th>Book</th><th>Borrowed</th><th>Due date</th><th>Status</th><th></th></tr></thead><tbody>${loans.map(loan => `<tr><td><b>${escapeHtml(loan.borrower.name)}</b><br><span class="muted">${escapeHtml(loan.borrower.username)}</span></td><td>${escapeHtml(loan.book.title)}</td><td>${escapeHtml(loan.borrowedAt)}</td><td>${escapeHtml(loan.dueAt)}</td><td><span class="directory-badge">${loan.overdue ? 'Overdue' : 'On loan'}</span></td><td><button class="return-btn" data-return="${escapeHtml(loan.id)}">Mark returned</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty-state">No active loans.</div>';
  // Staff receive the full directory through this staff-only screen. The API route has a deliberate role-check gap for the lab.
  $('directoryTab').innerHTML = '<div class="empty-state"><b>Member directory</b><p>Directory details are loaded when this tab is opened.</p></div>';
  showManagementTab(state.tab);
}
async function loadDirectory() {
  const result = await api('/api/management/directory');
  $('directoryTab').innerHTML = `<table class="table"><thead><tr><th>Member</th><th>Contact</th><th>Membership</th><th>Books on loan</th><th>Borrowed titles</th></tr></thead><tbody>${result.directory.map(member => `<tr><td><b>${escapeHtml(member.name)}</b><br><span class="muted">${escapeHtml(member.username)} · ${escapeHtml(member.role)}</span></td><td>${escapeHtml(member.email)}<br><span class="muted">${escapeHtml(member.phone)}</span></td><td><span class="directory-badge">${escapeHtml(member.membership)}</span></td><td>${member.activeLoans}</td><td>${member.borrowedBooks.map(escapeHtml).join('<br>') || '<span class="muted">—</span>'}</td></tr>`).join('')}</tbody></table>`;
}
function showManagementTab(tab) {
  state.tab = tab;
  for (const name of ['inventory', 'loans', 'directory']) $(name + 'Tab').classList.toggle('hidden', name !== tab);
  document.querySelectorAll('.management-tabs button').forEach(button => button.classList.toggle('selected', button.dataset.tab === tab));
  if (tab === 'directory') void loadDirectory().catch(err => toast(err.message, true));
}

$('loginOpen').addEventListener('click', showLogin);
$('welcomeLogin').addEventListener('click', showLogin);
$('exploreBtn').addEventListener('click', () => { $('loginCard').scrollIntoView({ behavior: 'smooth' }); showLogin(); });
$('logoutBtn').addEventListener('click', async () => { try { await api('/api/logout', { method: 'POST' }); } catch {} state.user = null; showLanding(); toast('You have signed out.'); });
$('loginForm').addEventListener('submit', async event => {
  event.preventDefault(); $('loginError').textContent = '';
  try { await login($('username').value.trim(), $('password').value); toast(`Welcome, ${state.user.name.split(' ')[0]}.`); }
  catch (error) { $('loginError').textContent = error.message; }
});
document.querySelectorAll('[data-user]').forEach(button => button.addEventListener('click', () => { $('username').value = button.dataset.user; $('password').value = 'library123'; }));
document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.view)));
$('searchInput').addEventListener('input', renderBooks);
$('categorySelect').addEventListener('change', renderBooks);
$('bookGrid').addEventListener('click', async event => {
  const button = event.target.closest('[data-add]'); if (!button) return;
  try { state.cart = await api('/api/cart/items', { method: 'POST', body: JSON.stringify({ bookId: button.dataset.add }) }); renderCart(); $('cartNavCount').textContent = state.cart.itemCount; toast('Added to your reading basket.'); }
  catch (error) { toast(error.message, true); }
});
$('cartItems').addEventListener('click', async event => {
  const button = event.target.closest('[data-remove]'); if (!button) return;
  try { state.cart = await api('/api/cart/items/' + encodeURIComponent(button.dataset.remove), { method: 'DELETE' }); renderCart(); toast('Removed from your basket.'); }
  catch (error) { toast(error.message, true); }
});
$('checkoutBtn').addEventListener('click', async () => {
  try { const result = await api('/api/checkout', { method: 'POST', body: '{}' }); toast(result.message); await refreshMemberData(); navigate('loans'); }
  catch (error) { toast(error.message, true); }
});
$('managementView').addEventListener('click', async event => {
  const tab = event.target.closest('[data-tab]');
  if (tab) { showManagementTab(tab.dataset.tab); return; }
  const stockButton = event.target.closest('[data-stock]');
  if (stockButton) {
    const value = Number($('stock-' + stockButton.dataset.stock).value);
    try { await api('/api/management/books/' + encodeURIComponent(stockButton.dataset.stock) + '/stock', { method: 'PATCH', body: JSON.stringify({ available: value }) }); await loadManagement(); toast('Stock updated.'); }
    catch (error) { toast(error.message, true); }
    return;
  }
  const returnButton = event.target.closest('[data-return]');
  if (returnButton) {
    try { await api('/api/management/loans/' + encodeURIComponent(returnButton.dataset.return) + '/return', { method: 'POST', body: '{}' }); await loadManagement(); toast('Book marked as returned.'); }
    catch (error) { toast(error.message, true); }
  }
});
async function init() {
  const me = await api('/api/me');
  if (me.user) { state.user = me.user; await refreshMemberData(); showApp(); }
  else { showLanding(); }
}
init().catch(error => { console.error(error); showLanding(); toast('Could not connect to the library server.', true); });
