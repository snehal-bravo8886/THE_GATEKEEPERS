import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';

const ROOT = fileURLToPath(new URL('.', import.meta.url));
const PUBLIC = resolve(ROOT, 'public');
const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT || 3200);
const PASSWORD = 'library123';
const sessions = new Map();
const today = new Date();
const plusDays = (days) => {
  const d = new Date(today);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
};

const users = [
  { id: 'alice', name: 'Aarav Mehta', username: 'alice', role: 'customer', email: 'aarav.mehta@example.test', phone: '+91 90000 10001', membership: 'Gold', joined: '2024-08-12' },
  { id: 'bob', name: 'Diya Sharma', username: 'bob', role: 'customer', email: 'diya.sharma@example.test', phone: '+91 90000 10002', membership: 'Silver', joined: '2025-01-21' },
  { id: 'maya', name: 'Maya Rao', username: 'maya', role: 'librarian', email: 'maya.rao@example.test', phone: '+91 90000 10003', membership: 'Staff', joined: '2023-04-03' },
  { id: 'manager', name: 'Rohan Iyer', username: 'manager', role: 'manager', email: 'rohan.iyer@example.test', phone: '+91 90000 10004', membership: 'Administrator', joined: '2022-11-10' }
];

const books = [
  { id: 'harry-potter', title: "Harry Potter and the Philosopher's Stone", author: 'J. K. Rowling', category: 'Fantasy', year: 1997, shelf: 'FIC-A1', total: 5, available: 4, borrowed: 1, rating: 4.9, accent: 'violet', description: 'A young wizard discovers a hidden world of magic, friendship and courage.' },
  { id: 'the-hobbit', title: 'The Hobbit', author: 'J. R. R. Tolkien', category: 'Fantasy', year: 1937, shelf: 'FIC-A2', total: 4, available: 3, borrowed: 1, rating: 4.8, accent: 'forest', description: 'Bilbo Baggins leaves his quiet home for a remarkable journey with dwarves.' },
  { id: 'the-alchemist', title: 'The Alchemist', author: 'Paulo Coelho', category: 'Fiction', year: 1988, shelf: 'FIC-B1', total: 5, available: 4, borrowed: 1, rating: 4.6, accent: 'amber', description: 'A shepherd follows a dream across the desert in search of a treasure.' },
  { id: 'kite-runner', title: 'The Kite Runner', author: 'Khaled Hosseini', category: 'Fiction', year: 2003, shelf: 'FIC-B2', total: 4, available: 4, borrowed: 0, rating: 4.7, accent: 'rose', description: 'A moving story of friendship, memory and the possibility of redemption.' },
  { id: 'wings-of-fire', title: 'Wings of Fire', author: 'A. P. J. Abdul Kalam', category: 'Biography', year: 1999, shelf: 'BIO-C1', total: 6, available: 5, borrowed: 1, rating: 4.8, accent: 'sky', description: 'The inspiring autobiography of a scientist, teacher and former president.' },
  { id: 'atomic-habits', title: 'Atomic Habits', author: 'James Clear', category: 'Self-growth', year: 2018, shelf: 'NF-D1', total: 5, available: 4, borrowed: 1, rating: 4.7, accent: 'mint', description: 'A practical guide to building good habits through small daily improvements.' },
  { id: 'sapiens', title: 'Sapiens', author: 'Yuval Noah Harari', category: 'History', year: 2011, shelf: 'NF-D2', total: 4, available: 4, borrowed: 0, rating: 4.6, accent: 'sand', description: 'A sweeping introduction to the history and development of humankind.' },
  { id: 'clean-code', title: 'Clean Code', author: 'Robert C. Martin', category: 'Technology', year: 2008, shelf: 'TECH-E1', total: 3, available: 3, borrowed: 0, rating: 4.5, accent: 'blue', description: 'A classic guide to writing readable, maintainable and thoughtful software.' }
];

const carts = {
  alice: [{ bookId: 'kite-runner', quantity: 1 }],
  bob: [{ bookId: 'sapiens', quantity: 1 }, { bookId: 'clean-code', quantity: 1 }],
  maya: [],
  manager: []
};

const loans = [
  { id: 'loan-1001', userId: 'alice', bookId: 'the-alchemist', borrowedAt: plusDays(-8), dueAt: plusDays(6), status: 'borrowed' },
  { id: 'loan-1002', userId: 'alice', bookId: 'wings-of-fire', borrowedAt: plusDays(-11), dueAt: plusDays(3), status: 'borrowed' },
  { id: 'loan-1003', userId: 'bob', bookId: 'the-hobbit', borrowedAt: plusDays(-5), dueAt: plusDays(9), status: 'borrowed' },
  { id: 'loan-1004', userId: 'bob', bookId: 'atomic-habits', borrowedAt: plusDays(-18), dueAt: plusDays(-4), status: 'borrowed' },
  { id: 'loan-1005', userId: 'maya', bookId: 'harry-potter', borrowedAt: plusDays(-3), dueAt: plusDays(11), status: 'borrowed' }
];

function json(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(data),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff'
  });
  res.end(data);
}

async function body(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 1024 * 1024) throw Object.assign(new Error('Request too large'), { status: 413 });
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); }
  catch { throw Object.assign(new Error('Invalid JSON body'), { status: 400 }); }
}

function cookieValue(req, key) {
  const header = req.headers.cookie || '';
  const part = header.split(';').map(x => x.trim()).find(x => x.startsWith(key + '='));
  return part ? decodeURIComponent(part.slice(key.length + 1)) : '';
}

function currentUser(req) {
  const token = cookieValue(req, 'library_session');
  const userId = sessions.get(token);
  return users.find(user => user.id === userId) || null;
}

function requireLogin(req, res) {
  const user = currentUser(req);
  if (!user) json(res, 401, { error: 'Please sign in to continue.' });
  return user;
}

function requireStaff(req, res) {
  const user = requireLogin(req, res);
  if (user && !['librarian', 'manager'].includes(user.role)) {
    json(res, 403, { error: 'This action is available to library staff only.' });
    return null;
  }
  return user;
}

function publicUser(user) {
  return { id: user.id, name: user.name, username: user.username, role: user.role, email: user.email, phone: user.phone, membership: user.membership, joined: user.joined };
}

function bookView(book) { return { ...book }; }
function cartView(userId) {
  const user = users.find(item => item.id === userId);
  const items = (carts[userId] || []).map(line => {
    const book = books.find(item => item.id === line.bookId);
    return book ? { book: bookView(book), quantity: line.quantity, lineTotal: line.quantity * 1 } : null;
  }).filter(Boolean);
  return { user: user ? { id: user.id, name: user.name, username: user.username } : null, items, itemCount: items.reduce((sum, item) => sum + item.quantity, 0) };
}

function loanView(loan) {
  const user = users.find(item => item.id === loan.userId);
  const book = books.find(item => item.id === loan.bookId);
  const overdue = loan.status === 'borrowed' && loan.dueAt < new Date().toISOString().slice(0, 10);
  return { ...loan, borrower: user ? publicUser(user) : null, book: book ? bookView(book) : null, overdue };
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  const path = url.pathname;

  if (req.method === 'GET' && path === '/api/health') return json(res, 200, { ok: true, service: 'Community Library demo API' });

  if (req.method === 'POST' && path === '/api/login') {
    const input = await body(req);
    const user = users.find(item => item.username === String(input.username || '').toLowerCase());
    if (!user || input.password !== PASSWORD) return json(res, 401, { error: 'Invalid username or password.' });
    const token = randomBytes(24).toString('hex');
    sessions.set(token, user.id);
    res.writeHead(200, { 'set-cookie': `library_session=${token}; HttpOnly; SameSite=Lax; Path=/`, 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    return res.end(JSON.stringify({ user: publicUser(user) }));
  }

  if (req.method === 'POST' && path === '/api/logout') {
    const token = cookieValue(req, 'library_session');
    sessions.delete(token);
    res.writeHead(200, { 'set-cookie': 'library_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0', 'content-type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ ok: true }));
  }

  if (req.method === 'GET' && path === '/api/me') {
    const user = currentUser(req);
    return json(res, 200, { user: user ? publicUser(user) : null });
  }

  if (req.method === 'GET' && path === '/api/books') return json(res, 200, { books: books.map(bookView) });

  if (req.method === 'GET' && path === '/api/cart') {
    const user = requireLogin(req, res); if (!user) return;
    return json(res, 200, cartView(user.id));
  }

  // Deliberate lab flaw: checks that someone is signed in, but never checks cart ownership.
  const cartMatch = path.match(/^\/api\/carts\/([a-z0-9_-]+)$/i);
  if (req.method === 'GET' && cartMatch) {
    const user = requireLogin(req, res); if (!user) return;
    const ownerId = cartMatch[1].toLowerCase();
    if (!carts[ownerId]) return json(res, 404, { error: 'Cart not found.' });
    return json(res, 200, cartView(ownerId));
  }

  if (req.method === 'POST' && path === '/api/cart/items') {
    const user = requireLogin(req, res); if (!user) return;
    const input = await body(req);
    const book = books.find(item => item.id === input.bookId);
    if (!book) return json(res, 404, { error: 'Book not found.' });
    if (book.available < 1) return json(res, 409, { error: 'No copies are currently available.' });
    const cart = carts[user.id];
    const line = cart.find(item => item.bookId === book.id);
    if (line) line.quantity += 1; else cart.push({ bookId: book.id, quantity: 1 });
    return json(res, 200, cartView(user.id));
  }

  const cartItemMatch = path.match(/^\/api\/cart\/items\/([a-z0-9_-]+)$/i);
  if (req.method === 'DELETE' && cartItemMatch) {
    const user = requireLogin(req, res); if (!user) return;
    carts[user.id] = carts[user.id].filter(item => item.bookId !== cartItemMatch[1]);
    return json(res, 200, cartView(user.id));
  }

  if (req.method === 'POST' && path === '/api/checkout') {
    const user = requireLogin(req, res); if (!user) return;
    const cart = carts[user.id];
    if (!cart.length) return json(res, 409, { error: 'Your cart is empty.' });
    const unavailable = cart.find(line => {
      const book = books.find(item => item.id === line.bookId);
      return !book || book.available < line.quantity;
    });
    if (unavailable) return json(res, 409, { error: 'A selected book no longer has enough copies available.' });
    const created = [];
    for (const line of cart) {
      const book = books.find(item => item.id === line.bookId);
      for (let i = 0; i < line.quantity; i += 1) {
        const loan = { id: `loan-${Date.now()}-${randomBytes(2).toString('hex')}`, userId: user.id, bookId: book.id, borrowedAt: plusDays(0), dueAt: plusDays(14), status: 'borrowed' };
        loans.unshift(loan); created.push(loanView(loan));
      }
      book.available -= line.quantity;
      book.borrowed += line.quantity;
    }
    carts[user.id] = [];
    return json(res, 201, { message: 'Books issued successfully.', loans: created });
  }

  if (req.method === 'GET' && path === '/api/loans') {
    const user = requireLogin(req, res); if (!user) return;
    return json(res, 200, { loans: loans.filter(loan => loan.userId === user.id && loan.status === 'borrowed').map(loanView) });
  }

  if (req.method === 'GET' && path === '/api/management/overview') {
    const user = requireStaff(req, res); if (!user) return;
    const active = loans.filter(loan => loan.status === 'borrowed');
    return json(res, 200, {
      books: books.map(bookView),
      activeLoans: active.length,
      overdue: active.filter(loan => loan.dueAt < new Date().toISOString().slice(0, 10)).length,
      members: users.filter(item => item.role === 'customer').length,
      availableCopies: books.reduce((sum, book) => sum + book.available, 0),
      borrowedCopies: books.reduce((sum, book) => sum + book.borrowed, 0)
    });
  }

  // Deliberate lab flaw: the management directory checks login, not librarian/manager role.
  if (req.method === 'GET' && path === '/api/management/directory') {
    const user = requireLogin(req, res); if (!user) return;
    const directory = users.map(member => ({
      ...publicUser(member),
      activeLoans: loans.filter(loan => loan.userId === member.id && loan.status === 'borrowed').length,
      borrowedBooks: loans.filter(loan => loan.userId === member.id && loan.status === 'borrowed').map(loan => books.find(book => book.id === loan.bookId)?.title).filter(Boolean)
    }));
    return json(res, 200, { directory });
  }

  if (req.method === 'GET' && path === '/api/management/loans') {
    const user = requireStaff(req, res); if (!user) return;
    return json(res, 200, { loans: loans.filter(loan => loan.status === 'borrowed').map(loanView) });
  }

  // Deliberate lab flaw: every signed-in user can change stock, even though the UI hides this for members.
  const stockMatch = path.match(/^\/api\/management\/books\/([a-z0-9_-]+)\/stock$/i);
  if (req.method === 'PATCH' && stockMatch) {
    const user = requireLogin(req, res); if (!user) return;
    const input = await body(req);
    const book = books.find(item => item.id === stockMatch[1]);
    if (!book) return json(res, 404, { error: 'Book not found.' });
    const quantity = Number(input.available);
    if (!Number.isInteger(quantity) || quantity < 0 || quantity > 1000) return json(res, 400, { error: 'Available quantity must be a whole number between 0 and 1000.' });
    book.available = quantity;
    book.total = Math.max(book.total, book.available + book.borrowed);
    return json(res, 200, { book: bookView(book) });
  }

  const returnMatch = path.match(/^\/api\/management\/loans\/([^/]+)\/return$/);
  if (req.method === 'POST' && returnMatch) {
    const user = requireStaff(req, res); if (!user) return;
    const loan = loans.find(item => item.id === returnMatch[1] && item.status === 'borrowed');
    if (!loan) return json(res, 404, { error: 'Active loan not found.' });
    const book = books.find(item => item.id === loan.bookId);
    loan.status = 'returned'; loan.returnedAt = plusDays(0);
    if (book) { book.available += 1; book.borrowed = Math.max(0, book.borrowed - 1); }
    return json(res, 200, { loan: loanView(loan) });
  }

  if (path.startsWith('/api/')) return json(res, 404, { error: 'API endpoint not found.' });
  if (req.method !== 'GET' && req.method !== 'HEAD') return json(res, 405, { error: 'Method not allowed.' });

  let requested = path === '/' ? 'index.html' : decodeURIComponent(path).replace(/^\/+/, '');
  let file = resolve(PUBLIC, requested);
  if (!file.startsWith(PUBLIC + sep) && file !== resolve(PUBLIC, 'index.html')) {
    res.writeHead(403); return res.end('Forbidden');
  }
  const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml' };
  try {
    const contents = await readFile(file);
    res.writeHead(200, { 'content-type': mime[extname(file)] || 'application/octet-stream', 'x-content-type-options': 'nosniff' });
    return req.method === 'HEAD' ? res.end() : res.end(contents);
  } catch {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    return res.end('Page not found.');
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Community Library is running at http://${HOST}:${PORT}`);
  console.log('Demo password for all accounts: ' + PASSWORD);
  console.log('Local-only lab. Do not expose this intentionally vulnerable app to the internet.');
});
