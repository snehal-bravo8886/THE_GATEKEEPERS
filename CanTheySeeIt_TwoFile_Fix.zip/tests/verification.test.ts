import { describe, expect, it, afterEach } from 'vitest';
import type { Server } from 'node:http';
import { createPromiseSchema } from '../shared/contracts.ts';
import type { SecurityPromise, TestCase } from '../shared/contracts.ts';
import { generateTests } from '../runner/src/generateTests.ts';
import { approvedFixtureUrl } from '../runner/src/fixtures.ts';
import { makeFixtureApp } from '../dev-fixture/app.ts';
import { runVerification } from '../runner/src/verify.ts';
import { evaluate, aggregate, compareRuns } from '../runner/src/verdict.ts';

const sample: SecurityPromise = {
  promiseId: 'demo-promise-123', title: 'Students see only their own exams',
  originalRequirement: 'Students must only be able to view their own exam results',
  confirmedPolicy: 'OWNER_ONLY_READ', targetProfileId: 'student-portal',
  ownerActorRef: 'alice', peerActorRef: 'bob', ownerFixtureRef: 'alice-exam',
  peerFixtureRef: 'bob-exam', deniedStatusPolicy: 'STRICT_403',
  testIds: ['T1', 'T2', 'T3', 'T4', 'T5'].map(t => `demo-promise-123:${t}`),
  createdAt: '2026-10-31T00:00:00.000Z'
};
let server: Server | undefined;
async function start(mode: Parameters<typeof makeFixtureApp>[0]) {
  server = await new Promise<Server>((resolve, reject) => {
    const s = makeFixtureApp(mode).listen(3001, '127.0.0.1', () => resolve(s));
    s.once('error', reject);
  });
}
afterEach(async () => {
  if (server) await new Promise<void>((resolve, reject) => server!.close(e => e ? reject(e) : resolve()));
  server = undefined;
});

describe('contract and generated tests', () => {
  it('requires explicit human confirmation, forbids bearer tokens', () => {
    const input = { ...sample, confirmed: true } as Record<string, unknown>;
    delete input.promiseId; delete input.testIds; delete input.createdAt;
    expect(createPromiseSchema.safeParse(input).success).toBe(true);
    expect(createPromiseSchema.safeParse({ ...input, confirmed: false }).success).toBe(false);
    expect(createPromiseSchema.safeParse({ ...input, bearerToken: 'real-secret' }).success).toBe(false);
  });
  it('generates five stable rule-bound checks and refuses public targets', () => {
    const tests = generateTests(sample);
    expect(tests.map(t => t.testId)).toEqual(sample.testIds);
    expect(tests.map(t => t.expectation)).toEqual(['ALLOW','ALLOW','DENY','DENY','DENY']);
    expect(() => approvedFixtureUrl('https://example.com/private')).toThrow();
    expect(() => approvedFixtureUrl('/api/other')).toThrow();
  });
});

describe('real local requests, verdicts and comparisons', () => {
  it('returns aggregate PASS for protected fixture and all five real checks', async () => {
    await start('protected');
    const run = await runVerification(sample, 'v1-protected');
    expect(run.aggregateVerdict).toBe('PASS');
    expect(run.results).toHaveLength(5);
    expect(run.coverage).toEqual({ configuredChecks: 5, conclusiveChecks: 5, unresolvedChecks: 0, confirmedFailures: 0 });
    expect(run.results[2].observed.httpStatus).toBe(403);
    expect(JSON.stringify(run)).not.toContain('synthetic-alice-token');
  });
  it('returns FAIL when Bob gets Alice exact synthetic marker', async () => {
    await start('regression');
    const run = await runVerification(sample, 'v2-regression');
    if (run.aggregateVerdict !== 'FAIL') {
      // Diagnostic output if a real request fails or a prerequisite is inconclusive.
      console.table(run.results.map(r => ({
        testId: r.testId, verdict: r.verdict, reasonCode: r.reasonCode,
        status: r.observed.httpStatus, fixtureMatched: r.observed.fixtureMatched
      })));
    }
    expect(run.aggregateVerdict).toBe('FAIL');
    expect(run.results[2].reasonCode).toBe('PRIVATE_FIXTURE_EXPOSED');
    expect(run.results[4].verdict).toBe('PASS');
  });
  it('prevents false PASS when Bob session is invalid', async () => {
    await start('expired');
    const run = await runVerification(sample, 'bad-session');
    expect(run.aggregateVerdict).toBe('INCONCLUSIVE');
    expect(run.results[1].reasonCode).toBe('CONTROL_NOT_PROVEN');
    expect(run.results[2].reasonCode).toBe('PREREQUISITE_FAILED');
  });
  it('returns INCONCLUSIVE for upstream 5xx', async () => {
    await start('error');
    const run = await runVerification(sample, 'server-error');
    expect(run.aggregateVerdict).toBe('INCONCLUSIVE');
    expect(run.results[0].reasonCode).toBe('TARGET_ERROR');
  });
  it('returns INCONCLUSIVE for 200 with no exact marker', async () => {
    await start('ambiguous');
    const run = await runVerification(sample, 'ambiguous');
    expect(run.aggregateVerdict).toBe('INCONCLUSIVE');
    expect(run.results[2].reasonCode).toBe('UNVERIFIED_DENIAL_OR_CONTENT');
  });
  it('rejects redirects without following to any external host', async () => {
    await start('redirect');
    const run = await runVerification(sample, 'redirect');
    expect(run.aggregateVerdict).toBe('INCONCLUSIVE');
    expect(run.results[0].reasonCode).toBe('REDIRECT_BLOCKED');
  });
  it('does not falsely conclude that an authenticated HTTP 401 is a valid ownership denial', () => {
    const test: TestCase = generateTests(sample)[2];
    const verdict = evaluate(test, sample, { status: 401, body: null, bytes: 2, error: null }, true);
    expect(verdict.verdict).toBe('INCONCLUSIVE');
  });
  it('aggregation prioritizes confirmed FAIL over unresolved checks', () => {
    const tests = generateTests(sample);
    const failure = evaluate(tests[2], sample, {
      status: 200,
      body: { id:'exam-a-101', ownerId:'alice', privateMarker:'SYNTHETIC-ALICE-EXAM-101-7fa9' },
      bytes: 90, error: null
    }, true);
    const unresolved = evaluate(tests[3], sample, { status:null, body:null, bytes:0, error:'NETWORK_OR_TIMEOUT' }, true);
    expect(aggregate([failure, unresolved]).aggregateVerdict).toBe('FAIL');
  });
  it('preserves stable comparisons across real fixture state changes', async () => {
    await start('protected');
    const first = await runVerification(sample, 'v1-protected');
    await new Promise<void>(resolve => server!.close(() => resolve()));
    server = undefined;
    await start('regression');
    const second = await runVerification(sample, 'v2-regression', first);
    expect(second.comparison?.aggregateTransition).toBe('PASS → FAIL');
    await new Promise<void>(resolve => server!.close(() => resolve()));
    server = undefined;
    await start('protected');
    const third = await runVerification(sample, 'v3-fixed', second);
    expect(third.comparison?.aggregateTransition).toBe('FAIL → PASS');
    expect(third.results.every(r => r.verdict === 'PASS')).toBe(true);
  });
});
