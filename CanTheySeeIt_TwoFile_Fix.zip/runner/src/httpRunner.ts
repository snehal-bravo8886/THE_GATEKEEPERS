import type { ActorRef } from '../../shared/contracts.ts';
import { approvedFixtureUrl, syntheticToken } from './fixtures.ts';

const TIMEOUT_MS = 2500;
const MAX_RESPONSE_BYTES = 32 * 1024;
export interface Observation {
  status: number | null;
  body: unknown;
  bytes: number;
  error: string | null;
}

// Only makes GET requests to exact, preapproved synthetic paths on 127.0.0.1:3001.
export async function observe(actor: ActorRef, path: string): Promise<Observation> {
  let target: URL;
  try { target = approvedFixtureUrl(path); }
  catch { return { status: null, body: null, bytes: 0, error: 'BLOCKED_TARGET' }; }
  const token = syntheticToken(actor);
  try {
    const response = await fetch(target, {
      method: 'GET', redirect: 'manual', signal: AbortSignal.timeout(TIMEOUT_MS),
      // Test fixture restarts on the same port between regression runs.
      // Do not reuse pooled keep-alive sockets from a previous fixture instance.
      headers: token ? { Authorization: `Bearer ${token}`, Accept: 'application/json', Connection: 'close' }
                     : { Accept: 'application/json', Connection: 'close' }
    });
    if (response.status >= 300 && response.status < 400) {
      await response.body?.cancel();
      return { status: response.status, body: null, bytes: 0, error: 'REDIRECT_BLOCKED' };
    }
    const reader = response.body?.getReader();
    if (!reader) return { status: response.status, body: null, bytes: 0, error: 'EMPTY_RESPONSE' };
    const chunks: Uint8Array[] = [];
    let total = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MAX_RESPONSE_BYTES) {
        await reader.cancel();
        return { status: response.status, body: null, bytes: total, error: 'RESPONSE_TOO_LARGE' };
      }
      chunks.push(value);
    }
    const raw = Buffer.concat(chunks.map(c => Buffer.from(c))).toString('utf8');
    if (raw.length === 0) return { status: response.status, body: null, bytes: total, error: null };
    try {
      return { status: response.status, body: JSON.parse(raw), bytes: total, error: null };
    } catch {
      return { status: response.status, body: null, bytes: total, error: 'MALFORMED_JSON' };
    }
  } catch {
    return { status: null, body: null, bytes: 0, error: 'NETWORK_OR_TIMEOUT' };
  }
}
